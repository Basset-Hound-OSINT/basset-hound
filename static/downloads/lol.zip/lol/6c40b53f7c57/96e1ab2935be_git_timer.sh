#!/bin/bash

# File: git_timer.sh

TMP_START="/tmp/git_timer_start"
TMP_LAST="/tmp/git_timer_last"
ALIAS_FILE="/tmp/git_timer_aliases"

start_timer() {
    now=$(date +%s)
    echo "$now" > "$TMP_START"
    echo "$now" > "$TMP_LAST"

    echo "✅ Timer started at $(date -d @$now)"

    cat <<EOF > "$ALIAS_FILE"
alias gcm='bash $(realpath "$0") commit'
alias gtimer-stop='bash $(realpath "$0") stop'
alias gtime='bash $(realpath "$0") time'
EOF

    echo "🔗 To use aliases in this terminal, run: source $ALIAS_FILE"
}

format_time() {
    secs=$1
    printf "%02d:%02d:%02d" $((secs/3600)) $(((secs%3600)/60)) $((secs%60))
}

commit_with_time() {
    if [ ! -f "$TMP_START" ]; then
        echo "❌ Timer not started. Run: bash $(realpath "$0") start"
        exit 1
    fi

    now=$(date +%s)
    start_time=$(cat "$TMP_START")
    last_time=$(cat "$TMP_LAST")

    diff=$((now - last_time))
    total=$((now - start_time))

    formatted_diff=$(format_time $diff)
    formatted_total=$(format_time $total)

    echo "$now" > "$TMP_LAST"

    custom_message="$*"
    if [ -z "$custom_message" ]; then
        full_message="Update after ($formatted_diff), ($formatted_total)"
    else
        full_message="$custom_message after ($formatted_diff), ($formatted_total)"
    fi

    echo "📝 Committing with message:"
    echo "\"$full_message\""
    git commit -m "$full_message"
}

print_git_times() {
    if [ ! -f "$TMP_START" ]; then
        echo "❌ Timer not started. Run: bash $(realpath "$0") start"
        return 1
    fi

    now=$(date +%s)
    start_time=$(cat "$TMP_START")
    last_time=$start_time

    if [ -f "$TMP_LAST" ]; then
        last_time=$(cat "$TMP_LAST")
    fi

    diff=$((now - last_time))
    total=$((now - start_time))

    formatted_diff=$(format_time $diff)
    formatted_total=$(format_time $total)

    echo "⏱️ Time since last commit: $formatted_diff"
    echo "🕒 Total time since start:  $formatted_total"
}

stop_timer() {
    rm -f "$TMP_START" "$TMP_LAST" "$ALIAS_FILE"
    echo "🛑 Timer stopped and aliases removed."
    echo "💡 You may want to run: unalias gcm; unalias gtime; unalias gtimer-stop"
}

# Main handler
case "$1" in
    start)
        start_timer
        ;;
    commit)
        shift
        commit_with_time "$@"
        ;;
    time)
        print_git_times
        ;;
    stop)
        stop_timer
        ;;
    *)
        echo "Usage:"
        echo "  bash git_timer.sh start         # Start the timer and create aliases"
        echo "  gcm <your message>              # Commit with time info"
        echo "  gtime                           # Show elapsed/total time"
        echo "  gtimer-stop                     # Stop timer and cleanup"
        ;;
esac
